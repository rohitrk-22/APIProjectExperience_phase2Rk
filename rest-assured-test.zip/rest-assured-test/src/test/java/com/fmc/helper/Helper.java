package com.fmc.helper;

import java.util.UUID;

import org.apache.commons.lang3.RandomStringUtils;
import com.github.javafaker.Faker;

public class Helper {

	protected static final String BASEURL = "http://Fmc-env.eba-5akrwvvr.us-east-1.elasticbeanstalk.com";
	protected static final String GET_TOKEN_API_ENDPOINT = "/fmc/token";
	protected static final String USER_SIGNUP_API_ENDPOINT = "/fmc/email-signup-automation";
	protected static final String VERIFY_OTP_API_ENDPOINT = "/fmc/verify-otp";
	protected static final String RESET_PASSWORD_API_ENDPOINT = "/fmc/reset-password";
	protected static final String DELETE_USER_API_ENDPOINT = "/fmc/delete-user";
	protected static final String LOGIN_API_ENDPOINT = "/fmc/login";
	protected static final String Reports_API_ENDPOINT = "/fmc/reports";
	protected static final String FileUpload_API_ENDPOINT = "/file/upload";
	protected static final String FileDownload_API_ENDPOINT = "/file"; 
	
	
	protected static String validEmailId;
	protected static String validPassword;
	protected static String resetPassword;
	protected static String validFullname;
	protected static String validPhoneNumber;
	protected static String UUID_requestId;
	protected static String invalidToken = "eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlVTRVIiXSwic3ViIjoiZm1jIiwiaWF0IjoxNjY5NDcyNzc1LCJleHAiOjE2Njk0Nzg3NzV9.iIOf8GR_jHrNiJ1rrparRLazATrELgRBTEFuupI6NbbkZyRyvhiFeV76FdIRd-EBRj3d7WTL57eyFxkrRJj123";
	protected static int invalidUserId = 31233333;
	protected static int invalidReportId = 336554443;
	
	public static void GenerateRandomData() {
		
		Faker faker = new Faker();
		validFullname  = faker.name().fullName();
		String emailSuffix = RandomStringUtils.randomAlphanumeric(4);
		validEmailId = validFullname.replaceAll("\\s", "")+emailSuffix+"@globant.com";
		validPassword = RandomStringUtils.randomAlphanumeric(8);
		String randomNumbers = RandomStringUtils.randomNumeric(5);
		validPhoneNumber = 86686+randomNumbers;
		resetPassword = RandomStringUtils.randomAlphanumeric(8);
		UUID uuid = UUID.randomUUID();
        UUID_requestId = uuid.toString();
	}
	
	
}
