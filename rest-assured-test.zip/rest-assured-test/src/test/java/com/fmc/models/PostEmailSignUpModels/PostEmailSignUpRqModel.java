package com.fmc.models.PostEmailSignUpModels;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class PostEmailSignUpRqModel {
	public String email_id;
    public String password;
    public String full_name;
}


