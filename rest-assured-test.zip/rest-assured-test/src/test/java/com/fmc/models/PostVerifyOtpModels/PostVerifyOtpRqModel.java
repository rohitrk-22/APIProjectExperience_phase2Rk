package com.fmc.models.PostVerifyOtpModels;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class PostVerifyOtpRqModel {
	public String email_id;
    public String full_name;
    public String phone_number;
    public String password;
    public String otp;
}


