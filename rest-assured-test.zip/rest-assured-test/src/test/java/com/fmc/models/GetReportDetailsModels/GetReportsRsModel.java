package com.fmc.models.GetReportDetailsModels;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GetReportsRsModel {
	
	public String status;
    public String message;
    public ArrayList<ContentRsModel> content;

}
