package com.fmc.models.GetReportDetailsModels;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReporterDetailsRsModel {

	public int report_id;
    public String request_id;
    public String report_date;
    public String reporter_fullname;
    public int reporter_age;
    public String primary_country_code;
    public String primary_contact_number;
    public String secondary_country_code;
    public String secondary_contact_number;
    public String reporter_gender;
    public String reporter_relation;
    public String parenting_type;
    public String contact_address_type;
    public String contact_address_line_1;
    public String contact_address_line_2;
    public String pincode;
    public String country;
    public String communication_language;
    public String status;
    public int child_id;
    public int incident_id;
    public int user_id;
}
