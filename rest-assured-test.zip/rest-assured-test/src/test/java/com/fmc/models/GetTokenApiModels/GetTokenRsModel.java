package com.fmc.models.GetTokenApiModels;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GetTokenRsModel {
	
	public String accessToken;
    public String tokenType;
    public int expires_in;

}
