package com.fmc.models.PostLoginModels;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class PostLoginRsModel {

	 public String status;
	 public String message;
	 public Content content;
    
	 public class Content{
		    public int userId;
		    public String token;
		    public long expires_in;
	}
}
