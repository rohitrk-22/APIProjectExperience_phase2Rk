package com.fmc.models.GetReportDetailsModels;


public class ContentRsModel {

	public ReporterDetailsRsModel reporter_details;
    public ChildDetailsRsModel child_details;
    public IncidentDetailsRsModel incident_details;

}
