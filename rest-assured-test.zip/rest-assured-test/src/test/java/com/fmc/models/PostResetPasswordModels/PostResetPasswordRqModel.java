package com.fmc.models.PostResetPasswordModels;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostResetPasswordRqModel {

	public String email_id;
    public String password;
    
}
