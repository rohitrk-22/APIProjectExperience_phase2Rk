package com.fmc.models.GetReportDetailsModels;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentDetailsRsModel {

	public int incident_id;
    public String incident_date;
    public String incident_brief;
    public String location;
    public String landmark_signs;
    public String nearby_police_station;
    public String nearby_NGO;
    public boolean allow_connect_police_NGO;
    public boolean self_verification;
    public boolean community_terms;
}
