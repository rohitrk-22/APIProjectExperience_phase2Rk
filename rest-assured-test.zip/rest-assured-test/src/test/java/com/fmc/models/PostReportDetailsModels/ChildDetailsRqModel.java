package com.fmc.models.PostReportDetailsModels;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChildDetailsRqModel {
	
	public String fullname;
    public int age;
    public String gender;
    public String height;
    public String weight;
    public String complexion;
    public String clothing;
    public String birth_signs;
    public String other_details;
    public Object image_file_key;
    public String nickname;

}
