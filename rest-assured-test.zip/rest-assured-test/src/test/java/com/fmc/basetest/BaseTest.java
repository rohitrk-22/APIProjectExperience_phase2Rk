package com.fmc.basetest;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertNotNull;
import org.testng.annotations.BeforeClass;

import com.fmc.helper.Helper;
import com.fmc.models.GetTokenApiModels.GetTokenRsModel;
import com.fmc.models.PostEmailSignUpModels.PostEmailSignUpRqModel;
import com.fmc.models.PostReportDetailsModels.ChildDetailsRqModel;
import com.fmc.models.PostReportDetailsModels.IncidentDetailsRqModel;
import com.fmc.models.PostReportDetailsModels.ReportDetailsRqModel;
import com.fmc.models.PostReportDetailsModels.ReporterDetailsRqModel;
import com.fmc.models.PostVerifyOtpModels.PostVerifyOtpRqModel;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class BaseTest extends Helper {

	protected static RequestSpecification requestSpec;
	protected static String accessToken;
	protected static String userId;
	protected static String report_Id;
	protected static String image_file_key;

	@BeforeClass()
	public static void setRequestSpecification() {
		requestSpec = new RequestSpecBuilder().setBaseUri(BASEURL).setContentType(ContentType.JSON).build();
		accessToken = getValidToken();
		GenerateRandomData();
	}


	public static String getValidToken() {

		Response response = given().log().all().spec(requestSpec).get(GET_TOKEN_API_ENDPOINT);
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(200));
		assertThat(response.as(GetTokenRsModel.class).getExpires_in(), equalTo(6000));
		assertThat(response.as(GetTokenRsModel.class).getTokenType(), equalTo("bearer"));
		assertNotNull(response.as(GetTokenRsModel.class).getAccessToken());
		JsonPath jsonPathEvaluator = response.jsonPath();
		String accessToken = jsonPathEvaluator.get("accessToken");
		return accessToken;
	}

	public Response postEmailSignUp() {

		PostEmailSignUpRqModel data = PostEmailSignUpRqModel.builder()
				.email_id(validEmailId)
				.password(validPassword)
				.full_name(validFullname)
				.build();

		Response response = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).body(data).post(USER_SIGNUP_API_ENDPOINT);
		return response;
	}

	public void postUserSignUpSuccess() {

		Response postEmailSignUpResponse = postEmailSignUp();
		postEmailSignUpResponse.prettyPrint();
		JsonPath jp = new JsonPath(postEmailSignUpResponse.asString());
		String otp = jp.getString("content.otp");

		PostVerifyOtpRqModel data = PostVerifyOtpRqModel.builder()
				.email_id(validEmailId)
				.password(validPassword)
				.full_name(validFullname)
				.phone_number(validPhoneNumber)
				.otp(otp)
				.build();

		Response response = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).body(data).put(VERIFY_OTP_API_ENDPOINT);

		JsonPath jpath = new JsonPath(response.asString()); 
		userId = jpath.getString("content.userId");

		response.prettyPrint();
	}

	public void reportCreation() {

		// Register User Sign UP first
		postUserSignUpSuccess();

		// Delete Password
		ChildDetailsRqModel data = ChildDetailsRqModel.builder().fullname(validFullname).age(20).gender("male").height("5.10ft").weight("66kg").complexion("fair").clothing("Red top and black pant").birth_signs("mark on right hand").other_details("wears spectacles").image_file_key(null).nickname("Kara").build();

		IncidentDetailsRqModel data2 = IncidentDetailsRqModel.builder().incident_date("2022-08-15T10:37:30Z").incident_brief("Child went missing near the school").location("Pune").landmark_signs("Near Kasba peth").nearby_police_station("City Police station").nearby_NGO("Samruddhi NGO").allow_connect_police_NGO(true).self_verification(true).community_terms(true).build();

		ReporterDetailsRqModel data3 = ReporterDetailsRqModel.builder().request_id(UUID_requestId).user_id(userId).report_date("2022-09-01T01:37:30Z").reporter_fullname("Samrat Kohli").reporter_age(40).reporter_gender("Male").reporter_relation("Father").parenting_type("Own Child").contact_address_type("Home").contact_address_line_1("Paud Road").contact_address_line_2("Kothrud").pincode("411058").country("India").primary_country_code("+91").primary_contact_number("1234567890").secondary_country_code("+91").secondary_contact_number("1234567891").communication_language("English").status("INCOMPLETE").build();

		ReportDetailsRqModel data4 = ReportDetailsRqModel.builder().child_details(data).incident_details(data2).reporter_details(data3).build();

		Response responseReports = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).body(data4).post(Reports_API_ENDPOINT);
		responseReports.prettyPrint();
		JsonPath jpath = new JsonPath(responseReports.asString()); 
		report_Id = jpath.getString("content");
	}

}
