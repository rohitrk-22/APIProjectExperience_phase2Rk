package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;

import org.testng.annotations.Test;

import com.fmc.basetest.BaseTest;
import com.fmc.models.PutFileUploadModels.FileUploadRsModel;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;

public class GetFileUploadTest extends BaseTest{
	
	@Test(priority=0,description = "Validate File upload API")
	public void verfiyFileUploadAPI_Test1() {
		
		requestSpec = new RequestSpecBuilder().setBaseUri(BASEURL).build();

		Response fileUploadResponse = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).multiPart("file",new File(System.getProperty("user.dir")+"/src/main/java/resources/Sample.jpeg")).put(FileUpload_API_ENDPOINT);
		fileUploadResponse.prettyPrint();
		image_file_key = fileUploadResponse.as(FileUploadRsModel.class).getImage_file_key();

		Response fileDownloadResponse = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).get(FileDownload_API_ENDPOINT+"/"+image_file_key);
		//fileDownloadResponse.prettyPrint();
		assertThat(fileDownloadResponse.statusCode(), equalTo(200));
	}

}
