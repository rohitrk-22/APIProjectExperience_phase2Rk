package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

import com.fmc.basetest.BaseTest;

import io.restassured.response.Response;

public class DeleteReportsTest extends BaseTest{
	
	@Test(priority=0,description = "Validate Delete Reports API")
	public void verfiyDeleteReportsAPI_Test1() {
		
		reportCreation();
		
		Response responseDeletePassword = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).delete(Reports_API_ENDPOINT+"/"+report_Id+"/users/"+userId);
		responseDeletePassword.prettyPrint();
		assertThat(responseDeletePassword.statusCode(), equalTo(200));
	}

	@Test(priority=1,description = "Validate Delete Reports API when user provides incorrect user id")
	public void verfiyDeleteReportsAPI_Test2() {
		
		reportCreation();
		
		Response responseDeletePassword = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).delete(Reports_API_ENDPOINT+"/"+report_Id+"/users/"+invalidUserId);
		responseDeletePassword.prettyPrint();
		assertThat(responseDeletePassword.statusCode(), equalTo(404));
	}
	
	@Test(priority=2,description = "Validate Delete Reports API when user provides incorrect report id")
	public void verfiyDeleteReportsAPI_Test3() {
		
		reportCreation();
		
		Response responseDeletePassword = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).delete(Reports_API_ENDPOINT+"/"+invalidReportId+"/users/"+userId);
		responseDeletePassword.prettyPrint();
		assertThat(responseDeletePassword.statusCode(), equalTo(404));
	}
	
	@Test(priority=3,description = "Validate Delete Reports API when user provides invalid token")
	public void verfiyDeleteReportsAPI_Test4() {
		
		reportCreation();
		
		Response responseDeletePassword = given().log().all().spec(requestSpec).header("Authorization","Bearer "+invalidToken).delete(Reports_API_ENDPOINT+"/"+report_Id+"/users/"+userId);
		responseDeletePassword.prettyPrint();
		assertThat(responseDeletePassword.statusCode(), equalTo(401));
	}
}
