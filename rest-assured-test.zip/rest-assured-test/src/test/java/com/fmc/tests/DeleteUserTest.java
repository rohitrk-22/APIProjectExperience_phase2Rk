package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import io.restassured.response.Response;
import org.testng.annotations.*;
import com.fmc.basetest.BaseTest;
import com.fmc.models.PostDeleteUserModels.PostDeletePasswordRqModel;



public class DeleteUserTest extends BaseTest {	

	@Test(priority=0,description = "Validate Delete User API")
	public void verfiyDeleteUserAPI_Test1() {
		
		// Register User Sign UP first
		postUserSignUpSuccess();
		
		// Delete Password
		PostDeletePasswordRqModel data = PostDeletePasswordRqModel.builder().email_id(validEmailId).build();
		
		Response responseDeletePassword = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).body(data).delete(DELETE_USER_API_ENDPOINT);
		responseDeletePassword.prettyPrint();
		assertThat(responseDeletePassword.statusCode(), equalTo(200));
		
	}
	
}
