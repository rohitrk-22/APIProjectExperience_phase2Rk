package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import org.testng.annotations.*;

import com.fmc.basetest.BaseTest;
import com.fmc.models.PostVerifyOtpModels.PostVerifyOtpRqModel;
import com.fmc.models.PostVerifyOtpModels.PostVerifyOtpRsModel;


public class VerifyOtpApiTest extends BaseTest {	

	@Test(priority=0,description = "Validate Post Verify OTP API")
	public void verfiyOtpAPI_Test1() {
		
		Response postEmailSignUpResponse = postEmailSignUp();
		postEmailSignUpResponse.prettyPrint();
		JsonPath jp = new JsonPath(postEmailSignUpResponse.asString());
		String otp = jp.getString("content.otp");
		
		PostVerifyOtpRqModel data = PostVerifyOtpRqModel.builder()
				.email_id(validEmailId)
				.password(validPassword)
				.full_name(validFullname)
				.phone_number(validPhoneNumber)
				.otp(otp)
				.build();
		
		Response response = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).body(data).put(VERIFY_OTP_API_ENDPOINT);
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(200));
		assertThat(response.as(PostVerifyOtpRsModel.class).getStatus(), equalTo("Success"));
		assertThat(response.as(PostVerifyOtpRsModel.class).getMessage(), equalTo("Signed up successfully"));
		assertThat(response.as(PostVerifyOtpRsModel.class).getContent().userId,notNullValue());
	}
	
}
