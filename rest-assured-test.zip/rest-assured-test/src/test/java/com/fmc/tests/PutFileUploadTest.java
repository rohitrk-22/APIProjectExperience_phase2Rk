package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertNotNull;

import java.io.File;

import org.testng.annotations.Test;

import com.fmc.basetest.BaseTest;
import com.fmc.models.PutFileUploadModels.FileUploadRsModel;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;

public class PutFileUploadTest extends BaseTest{

	@Test(priority=0,description = "Validate File upload API")
	public void verfiyFileUploadAPI_Test1() {

		requestSpec = new RequestSpecBuilder().setBaseUri(BASEURL).build();

		Response fileUploadResponse = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).multiPart("file",new File(System.getProperty("user.dir")+"/src/main/java/resources/Sample.jpeg")).put(FileUpload_API_ENDPOINT);
		fileUploadResponse.prettyPrint();
		assertThat(fileUploadResponse.statusCode(), equalTo(201));
		assertNotNull(fileUploadResponse.as(FileUploadRsModel.class).getImage_file_key());
		image_file_key = fileUploadResponse.as(FileUploadRsModel.class).getImage_file_key();
	}
	
	@Test(priority=1,description = "Validate File upload API when incorrect http method is used instead of PUT")
	public void verfiyFileUploadAPI_Test2() {

		requestSpec = new RequestSpecBuilder().setBaseUri(BASEURL).build();

		Response fileUploadResponse = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).multiPart("file",new File(System.getProperty("user.dir")+"/src/main/java/resources/Sample.jpeg")).post(FileUpload_API_ENDPOINT);
		assertThat(fileUploadResponse.statusCode(), equalTo(405));
		fileUploadResponse.prettyPrint();
	}
}
