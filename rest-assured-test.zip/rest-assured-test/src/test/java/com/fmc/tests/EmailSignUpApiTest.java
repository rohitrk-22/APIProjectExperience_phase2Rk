package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import io.restassured.response.Response;

import org.testng.annotations.*;

import com.fmc.basetest.BaseTest;
import com.fmc.models.PostEmailSignUpModels.PostEmailSignUpErrorRsModel;
import com.fmc.models.PostEmailSignUpModels.PostEmailSignUpRqModel;
import com.fmc.models.PostEmailSignUpModels.PostEmailSignUpRsModel;


public class EmailSignUpApiTest extends BaseTest {	

	@Test(priority=0,description = "Verify Email SignUp is Successful")
	public void verfiyEmailSignUpAPI_Test1() {

		Response response = postEmailSignUp();
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(201));
		assertThat(response.as(PostEmailSignUpRsModel.class).getStatus(), equalTo("Success"));
		assertThat(response.as(PostEmailSignUpRsModel.class).getMessage(), equalTo("Email sent for OTP verification"));
	}	
	
	
	@Test(priority=1,description = "Verify error message return by email-signup-automation API when mandatory field 'email_id' is not provided in request body")
	public void verfiyEmailSignUpAPI_Test2() {
		
		PostEmailSignUpRqModel data = PostEmailSignUpRqModel.builder()
				.password(validPassword)
				.full_name(validFullname)
				.build();
		
		Response response = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).body(data).post(USER_SIGNUP_API_ENDPOINT);
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(400));
		assertThat(response.as(PostEmailSignUpErrorRsModel.class).getMessage(), equalTo("Proper Error Message"));
	}
	
	
	@Test(priority=2,description = "Verify response of email-signup-automation API when invalid token of same length is provided in header")
	public void verfiyEmailSignUpAPI_Test3() {
		
		PostEmailSignUpRqModel data = PostEmailSignUpRqModel.builder()
				.email_id(validEmailId)
				.password(validPassword)
				.full_name(validFullname)
				.build();
		
		String invalidToken="eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlVTRVIiXSwic3ViIjoiZm1jIiwiaWF0IjoxNjY5NDcyNzc1LCJleHAiOjE2Njk0Nzg3NzV9.iIOf8GR_jHrNiJ1rrparRLazATrELgRBTEFuupI6NbbkZyRyvhiFeV76FdIRd-EBRj3d7WTL57eyFxkrRJj123";
		
		Response response = given().log().all().spec(requestSpec).header("Authorization","Bearer "+invalidToken).body(data).post(USER_SIGNUP_API_ENDPOINT);
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(401));
	}
	
	
	@Test(priority=3,description = "Verify error message return by email-signup-automation API when invalid 'email_id' is provided in request body")
	public void verfiyEmailSignUpAPI_Test4() {
		
		String invalidEmail="Invalid.@email@globant.com";
		
		PostEmailSignUpRqModel data = PostEmailSignUpRqModel.builder()
				.email_id(invalidEmail)
				.password(validPassword)
				.full_name(validFullname)
				.build();
		
		Response response = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).body(data).post(USER_SIGNUP_API_ENDPOINT);
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(400));
		assertThat(response.as(PostEmailSignUpErrorRsModel.class).getMessage(), equalTo("Proper Error Message"));
	}
}
