package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import io.restassured.response.Response;
import org.testng.annotations.*;
import com.fmc.basetest.BaseTest;
import com.fmc.models.PostResetPasswordModels.PostResetPasswordRqModel;
import com.fmc.models.PostResetPasswordModels.PostResetPasswordRsModel;


public class ResetPasswordTest extends BaseTest {	

	@Test(priority=0,description = "Validate Reset Password API")
	public void verfiyResetPasswordAPI_Test1() {
		
		// Register User Sign UP first
		postUserSignUpSuccess();
		
		// Reset Password
		PostResetPasswordRqModel data = PostResetPasswordRqModel.builder()
				.email_id(validEmailId)
				.password(resetPassword)
				.build();
		
		Response responseResetPassword = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).body(data).put(RESET_PASSWORD_API_ENDPOINT);
		responseResetPassword.prettyPrint();
		assertThat(responseResetPassword.statusCode(), equalTo(200));
		assertThat(responseResetPassword.as(PostResetPasswordRsModel.class).getStatus(), equalTo("Success"));
		assertThat(responseResetPassword.as(PostResetPasswordRsModel.class).getMessage(), equalTo("Password reset successfully."));
	}
	
}
