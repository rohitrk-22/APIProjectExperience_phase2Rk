package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertNotNull;

import org.testng.annotations.Test;

import com.fmc.basetest.BaseTest;
import com.fmc.models.GetReportDetailsModels.GetReportsRsModel;

import io.restassured.response.Response;

public class GetReportsTest extends BaseTest{

	@Test(priority=0,description = "Verify Get reports API")
	public void verfiyGetReportsAPI_Test1() {
		
		reportCreation();
		
		Response response = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).get(Reports_API_ENDPOINT+"/"+userId);
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(200));
		assertThat(response.as(GetReportsRsModel.class).getStatus(), equalTo("Success"));
		assertThat(response.as(GetReportsRsModel.class).getMessage(), equalTo("Success"));
		assertNotNull(response.as(GetReportsRsModel.class).getContent());
	}
	
	
	@Test(priority=1,description = "Get reports API should return 405 status code if any other HTTP method is use instead of GET")
	public void verfiyGetReportsAPI_Test2() {
		
		reportCreation();
		
		Response response = given().log().all().spec(requestSpec).header("Authorization","Bearer "+accessToken).post(Reports_API_ENDPOINT+"/"+userId);
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(405));
	}
}
