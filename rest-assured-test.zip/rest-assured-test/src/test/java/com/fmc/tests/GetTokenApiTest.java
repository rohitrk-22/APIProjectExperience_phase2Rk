package com.fmc.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.testng.Assert.assertNotNull;
import io.restassured.response.Response;

import org.testng.annotations.*;

import com.fmc.basetest.BaseTest;
import com.fmc.models.GetTokenApiModels.GetTokenRsModel;


public class GetTokenApiTest extends BaseTest {	

	@Test(priority=0,description = "Verify Get token API")
	public void verfiyGetTokenAPI_Test1() {
		Response response = given().log().all().spec(requestSpec).get(GET_TOKEN_API_ENDPOINT);
		assertThat(response.statusCode(), equalTo(200));
		assertThat(response.as(GetTokenRsModel.class).getExpires_in(), equalTo(6000));
		assertThat(response.as(GetTokenRsModel.class).getTokenType(), equalTo("bearer"));
		assertNotNull(response.as(GetTokenRsModel.class).getAccessToken());
	}
	
	
	@Test(priority=1,description = "Get token API should return 405 status code if any other HTTP method is use instead of GET")
	public void verfiyGetTokenAPI_Test2() {
		Response response = given().log().all().spec(requestSpec).post(GET_TOKEN_API_ENDPOINT);
		response.prettyPrint();
		assertThat(response.statusCode(), equalTo(405));
	}

	
}
